import 'package:eatplek_vendor_web/constants/colors.dart';
import 'package:eatplek_vendor_web/constants/prefferences.dart';
import 'package:eatplek_vendor_web/screens/earnings/model/earnings_model.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../view_model/revenue_notify_listner.dart';

class PaymentsEarningsView extends StatefulWidget {
  const PaymentsEarningsView({super.key});

  @override
  State<PaymentsEarningsView> createState() => _PaymentsEarningsViewState();
}

class _PaymentsEarningsViewState extends State<PaymentsEarningsView> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final p = context.read<RevenueNotifylistner>();
      p.getRevenueDataFn(context: context);
      p.getAllEarningFn(context: context, page: 1);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _TopBar(),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Page title
                Row(
                  children: [
                    Text(
                      'Payments & Earnings',
                      style: GoogleFonts.urbanist(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: AppColor.black,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      '- Track your sales, earnings, and payouts at a glance',
                      style: GoogleFonts.urbanist(
                        fontSize: 13,
                        color: AppColor.black60,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                _StatsRow(),
                const SizedBox(height: 24),
                _EarningsTable(),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// ─── Top bar ─────────────────────────────────────────────────────────────────
class _TopBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final hour = DateTime.now().hour;
    final greeting = hour < 12
        ? 'Good Morning,'
        : hour < 17
        ? 'Good Afternoon,'
        : 'Good Evening,';

    return Container(
      height: 64,
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                greeting,
                style: GoogleFonts.urbanist(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppColor.black,
                ),
              ),
              Text(
                AppPref.userName,
                style: GoogleFonts.urbanist(
                  fontSize: 12,
                  color: AppColor.black60,
                ),
              ),
            ],
          ),
          const Spacer(),
          Text(
            AppPref.userName,
            style: GoogleFonts.urbanist(
              fontSize: 13,
              fontWeight: FontWeight.w500,
              color: AppColor.black,
            ),
          ),
          const SizedBox(width: 10),
          CircleAvatar(
            radius: 18,
            backgroundColor: AppColor.darkBlue.withOpacity(0.12),
            child: Text(
              AppPref.userName.isNotEmpty
                  ? AppPref.userName[0].toUpperCase()
                  : 'V',
              style: GoogleFonts.urbanist(
                color: AppColor.darkBlue,
                fontWeight: FontWeight.w700,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Stats row ────────────────────────────────────────────────────────────────
class _StatsRow extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<RevenueNotifylistner>(
      builder: (context, p, _) {
        final stats = p.earningStatsModel?.data;
        return Row(
          children: [
            _StatCard(
              label: 'Total Earnings',
              value: stats != null ? 'Rs.${stats.totalEarnings ?? 0}' : '--',
              icon: Icons.account_balance_wallet_outlined,
              iconBg: const Color(0xFFEDE9FE),
              iconColor: const Color(0xFF7C3AED),
              isLoading: p.isLoadingEarningStats,
            ),
            const SizedBox(width: 16),
            _StatCard(
              label: 'Pending Payout',
              value: stats != null ? 'Rs. ${stats.pendingPayout ?? 0}' : '--',
              icon: Icons.trending_up_rounded,
              iconBg: const Color(0xFFFFF7E6),
              iconColor: const Color(0xFFD97706),
              isLoading: p.isLoadingEarningStats,
            ),
            const SizedBox(width: 16),
            _StatCard(
              label: 'Total Orders',
              value: stats?.totalOrders?.toString() ?? '--',
              icon: Icons.shopping_bag_outlined,
              iconBg: const Color(0xFFFFEDE9),
              iconColor: const Color(0xFFEF4444),
              isLoading: p.isLoadingEarningStats,
            ),
            const SizedBox(width: 16),
            _StatCard(
              label: 'Pending Orders',
              value: stats?.pendingOrders?.toString() ?? '--',
              icon: Icons.pending_outlined,
              iconBg: const Color(0xFFE6F4EA),
              iconColor: const Color(0xFF16A34A),
              isLoading: p.isLoadingEarningStats,
            ),
          ],
        );
      },
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color iconBg;
  final Color iconColor;
  final bool isLoading;

  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.iconBg,
    required this.iconColor,
    required this.isLoading,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFE5E7EB)),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: GoogleFonts.urbanist(
                      fontSize: 12,
                      color: AppColor.black60,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  isLoading
                      ? Container(
                          height: 24,
                          width: 70,
                          decoration: BoxDecoration(
                            color: const Color(0xFFE5E7EB),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        )
                      : Text(
                          value,
                          style: GoogleFonts.urbanist(
                            fontSize: 22,
                            fontWeight: FontWeight.w700,
                            color: AppColor.black,
                          ),
                        ),
                ],
              ),
            ),
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: iconBg,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: iconColor, size: 22),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Earnings table ───────────────────────────────────────────────────────────
class _EarningsTable extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<RevenueNotifylistner>(
      builder: (context, p, _) {
        final orders = p.earningsModel?.data?.orders ?? [];
        final pagination = p.earningsModel?.data?.pagination;

        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFE5E7EB)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Table title
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                child: Text(
                  'Payments & Earnings',
                  style: GoogleFonts.urbanist(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: AppColor.black,
                  ),
                ),
              ),
              const SizedBox(height: 12),

              // Header
              Container(
                color: const Color(0xFFF5F6FA),
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 12,
                ),
                child: const Row(
                  children: [
                    _HeaderCell('Order ID', flex: 2),
                    _HeaderCell('Date', flex: 3),
                    _HeaderCell('Order Type', flex: 3),
                    _HeaderCell('Amount', flex: 2),
                    _HeaderCell('Status', flex: 2),
                  ],
                ),
              ),

              // Body
              if (p.isLoading)
                const Padding(
                  padding: EdgeInsets.all(60),
                  child: Center(child: CircularProgressIndicator()),
                )
              else if (orders.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(60),
                  child: Center(
                    child: Text(
                      'No earnings found',
                      style: GoogleFonts.urbanist(
                        color: AppColor.black60,
                        fontSize: 14,
                      ),
                    ),
                  ),
                )
              else
                ...orders.map((order) => _EarningRow(order: order)),

              // Pagination
              if (pagination != null) _PaginationBar(pagination: pagination),
            ],
          ),
        );
      },
    );
  }
}

class _HeaderCell extends StatelessWidget {
  final String text;
  final int flex;
  const _HeaderCell(this.text, {required this.flex});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: flex,
      child: Text(
        text,
        style: GoogleFonts.urbanist(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: AppColor.black60,
        ),
      ),
    );
  }
}

class _EarningRow extends StatelessWidget {
  final Order order;
  const _EarningRow({required this.order});

  @override
  Widget build(BuildContext context) {
    final date = order.createdAt != null
        ? DateFormat('dd-MM-yyyy').format(order.createdAt!)
        : '--';

    return Container(
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Color(0xFFF1F5F9))),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Text(
              '#${order.orderId ?? ''}',
              style: GoogleFonts.urbanist(fontSize: 13, color: AppColor.black),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              date,
              style: GoogleFonts.urbanist(fontSize: 13, color: AppColor.black),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              order.serviceType ?? '',
              style: GoogleFonts.urbanist(fontSize: 13, color: AppColor.black),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              '₹${order.amount ?? 0}',
              style: GoogleFonts.urbanist(fontSize: 13, color: AppColor.black),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              order.orderStatus ?? '',
              style: GoogleFonts.urbanist(
                fontSize: 13,
                color: (order.orderStatus ?? '').toLowerCase() == 'completed'
                    ? const Color(0xFF16A34A)
                    : AppColor.black60,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Pagination ───────────────────────────────────────────────────────────────
class _PaginationBar extends StatelessWidget {
  final EarningsPagination pagination;
  const _PaginationBar({required this.pagination});

  @override
  Widget build(BuildContext context) {
    final start = ((pagination.page ?? 1) - 1) * (pagination.limit ?? 8) + 1;
    final end = ((pagination.page ?? 1) * (pagination.limit ?? 8)).clamp(
      0,
      pagination.total ?? 0,
    );

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
      child: Row(
        children: [
          Text(
            '$start – $end of ${pagination.total ?? 0} items',
            style: GoogleFonts.urbanist(fontSize: 12, color: AppColor.black60),
          ),
          const Spacer(),
          _PageButton(
            label: 'Previous',
            enabled: (pagination.page ?? 1) > 1,
            onTap: () => context.read<RevenueNotifylistner>().getAllEarningFn(
              context: context,
              page: (pagination.page ?? 1) - 1,
            ),
          ),
          const SizedBox(width: 8),
          _PageButton(
            label: 'Next',
            enabled: (pagination.page ?? 1) < (pagination.totalPages ?? 1),
            onTap: () => context.read<RevenueNotifylistner>().getAllEarningFn(
              context: context,
              page: (pagination.page ?? 1) + 1,
            ),
          ),
        ],
      ),
    );
  }
}

class _PageButton extends StatelessWidget {
  final String label;
  final bool enabled;
  final VoidCallback onTap;

  const _PageButton({
    required this.label,
    required this.enabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: enabled ? Colors.white : const Color(0xFFF5F6FA),
          border: Border.all(color: const Color(0xFFE5E7EB)),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Text(
          label,
          style: GoogleFonts.urbanist(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: enabled ? AppColor.black : AppColor.black40,
          ),
        ),
      ),
    );
  }
}
